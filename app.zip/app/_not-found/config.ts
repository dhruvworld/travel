// Force dynamic rendering for not found page
export const dynamic = 'force-dynamic'
export const revalidate = false
export const fetchCache = 'force-no-store'
