"use client";

import FeaturedPackagesEditor from "@/components/admin/FeaturedPackagesEditor";

export default function FeaturedPackagesPage() {
  return <FeaturedPackagesEditor />;
}
