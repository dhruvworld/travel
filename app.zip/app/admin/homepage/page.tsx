"use client";

import HomePageEditor from "@/components/admin/HomePageEditor";

export default function AdminHomePage() {
  return <HomePageEditor />;
}
