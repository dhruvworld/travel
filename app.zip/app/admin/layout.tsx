'use client';

import Link from 'next/link';
import { ReactNode } from 'react';
import { usePathname } from 'next/navigation';
import { 
  LayoutDashboard, 
  Package, 
  MessageSquare,
  Image as ImageIcon, 
  Car,
  Building2,
  Globe,
  Tag,
  LogOut,
  ChevronRight
} from 'lucide-react';

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <div className="bg-white text-gray-800 font-sans">
      <header className="bg-blue-700 text-white px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-xl font-semibold">Shubham Travel Admin</h1>
          <nav>
            <ul className="flex space-x-6">
              <li><a href="/admin" className="hover:text-blue-200">Dashboard</a></li>
              <li><a href="/admin/home" className="hover:text-blue-200">Homepage</a></li>
              <li><a href="/admin/packages" className="hover:text-blue-200">Packages</a></li>
              <li><a href="/" className="hover:text-blue-200">View Site</a></li>
            </ul>
          </nav>
        </div>
      </header>
      <main className="max-w-7xl mx-auto p-6">{children}</main>
    </div>
  );
}
