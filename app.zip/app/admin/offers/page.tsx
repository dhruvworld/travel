"use client";

import OffersEditor from "@/components/admin/OffersEditor";

export default function AdminOffersPage() {
  return <OffersEditor />;
}
