'use client';

import dynamic from "next/dynamic";

// Dynamically import the Prisma-related component to avoid runtime errors
const AdminPageContent = dynamic(() => import("./AdminPageContent"), { ssr: false });

export default function Page() {
  return <AdminPageContent />;
}