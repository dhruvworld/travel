"use client";

import TourManager from "@/components/admin/TourManager";

export default function AdminToursPage() {
  return <TourManager />;
}
