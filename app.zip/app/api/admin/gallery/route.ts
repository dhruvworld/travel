import { NextResponse } from 'next/server';
import prisma from '@/lib/db/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';

export async function GET() {
  try {
    const photos = await prisma.photo.findMany({ 
      orderBy: { createdAt: 'desc' } 
    });
    return NextResponse.json(photos);
  } catch (error) {
    console.error('Error fetching gallery photos:', error);
    return NextResponse.json(
      { error: 'Failed to fetch gallery photos' }, 
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const body = await req.json();
    
    if (!body.url || !body.cloudId) {
      return NextResponse.json(
        { error: 'URL and cloudId are required' }, 
        { status: 400 }
      );
    }
    
    const photo = await prisma.photo.create({
      data: body
    });
    
    return NextResponse.json(photo);
  } catch (error) {
    console.error('Error creating gallery photo:', error);
    return NextResponse.json(
      { error: 'Failed to create gallery photo' }, 
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const body = await req.json();
    const { id, ...data } = body;
    
    if (!id) {
      return NextResponse.json(
        { error: 'Image ID is required' }, 
        { status: 400 }
      );
    }
    
    const updated = await prisma.galleryImage.update({
      where: { id },
      data
    });
    
    return NextResponse.json(updated);
  } catch (error) {
    console.error('Error updating gallery image:', error);
    return NextResponse.json(
      { error: 'Failed to update gallery image' }, 
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const { id } = await req.json();
    
    if (!id) {
      return NextResponse.json(
        { error: 'Image ID is required' }, 
        { status: 400 }
      );
    }
    
    await prisma.galleryImage.delete({
      where: { id }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting gallery image:', error);
    return NextResponse.json(
      { error: 'Failed to delete gallery image' }, 
      { status: 500 }
    );
  }
}
