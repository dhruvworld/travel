import { NextResponse } from 'next/server';
import prisma from '@/lib/db/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';

export async function GET() {
  try {
    const offers = await prisma.offer.findMany({ 
      orderBy: { createdAt: 'desc' } 
    });
    return NextResponse.json(offers);
  } catch (error) {
    console.error('Error fetching offers:', error);
    return NextResponse.json(
      { error: 'Failed to fetch offers' }, 
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const body = await req.json();
    
    if (!body.title || !body.image || !body.cloudId) {
      return NextResponse.json(
        { error: 'Title, image URL, and cloudId are required' }, 
        { status: 400 }
      );
    }
    
    const offer = await prisma.offer.create({
      data: {
        title: body.title,
        description: body.description || '', // Add required description field
        image: body.image,
        cloudId: body.cloudId,
        subtitle: body.subtitle || null, // Make subtitle optional
        discount: body.discount || 0, // Add required discount field
        active: body.active !== undefined ? body.active : true
      }
    });
    
    return NextResponse.json(offer);
  } catch (error) {
    console.error('Error creating offer:', error);
    return NextResponse.json(
      { error: 'Failed to create offer' }, 
      { status: 500 }
    );
  }
}
