import { NextResponse } from 'next/server';
import prisma from '@/lib/db/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const id = params.id;
    
    if (!id) {
      return NextResponse.json(
        { error: 'Package ID is required' }, 
        { status: 400 }
      );
    }

    const existing = await prisma.package.findUnique({ 
      where: { id } 
    });

    if (!existing) {
      return NextResponse.json(
        { error: 'Package not found' }, 
        { status: 404 }
      );
    }

    const updated = await prisma.package.update({
      where: { id },
      data: { featured: !existing.featured }
    });
    
    return NextResponse.json(updated);
  } catch (error) {
    console.error('Error toggling package featured status:', error);
    return NextResponse.json(
      { error: 'Failed to toggle package featured status' }, 
      { status: 500 }
    );
  }
}
