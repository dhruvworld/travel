import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import prisma from '@/lib/db/prisma';
import { authOptions } from '@/lib/auth-options';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { title, url } = await request.json();
    
    if (!url) {
      return NextResponse.json(
        { error: 'Image URL is required' }, 
        { status: 400 }
      );
    }

    const updatedImage = await prisma.galleryImage.update({
      where: { id: params.id },
      data: {
        title: title || 'Untitled Image',
        url
      }
    });
    
    return NextResponse.json(updatedImage);
  } catch (error) {
    console.error(`Error updating gallery image ${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to update gallery image' }, 
      { status: 500 }
    );
  }
}

export async function DELETE(
  _: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    await prisma.galleryImage.delete({
      where: { id: params.id }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(`Error deleting gallery image ${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to delete gallery image' }, 
      { status: 500 }
    );
  }
}
