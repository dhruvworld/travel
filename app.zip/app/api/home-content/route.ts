import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db/prisma';
import NodeCache from 'node-cache';

const cache = new NodeCache({ stdTTL: 3600 }); // Cache for 1 hour

export async function GET() {
  const cacheKey = 'home-content';
  const cachedContent = cache.get(cacheKey);

  if (cachedContent) {
    return NextResponse.json(cachedContent);
  }

  try {
    const content = await prisma.homeContent.findFirst({
      select: {
        title: true,
        subtitle: true,
        heroText: true,
        heroImage: true,
      },
    });

    const defaultContent = {
      title: 'Explore Beautiful India',
      subtitle: 'Discover the beauty and culture of incredible India',
      heroText: 'Your journey begins here',
      heroImage: '/images/hero-default.jpg',
    };

    const response = content || defaultContent;
    cache.set(cacheKey, response);

    return NextResponse.json(response);
  } catch (error) {
    console.error('Error fetching home content:', error);
    return NextResponse.json(
      { error: 'Failed to fetch home content' },
      { status: 500 }
    );
  }
}
