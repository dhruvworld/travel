import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import prisma from '@/lib/db/prisma';
import { authOptions } from '@/lib/auth-options';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { 
      title, 
      description, 
      code, 
      discountPercent, 
      startDate, 
      endDate, 
      image,
      active 
    } = await request.json();
    
    if (!title || !description) {
      return NextResponse.json(
        { error: 'Title and description are required' }, 
        { status: 400 }
      );
    }

    const updatedOffer = await prisma.specialOffer.update({
      where: { id: params.id },
      data: {
        title,
        description,
        code,
        discountPercent: discountPercent ? parseInt(discountPercent.toString()) : null,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        image,
        active
      }
    });
    
    return NextResponse.json(updatedOffer);
  } catch (error) {
    console.error(`Error updating offer ${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to update offer' }, 
      { status: 500 }
    );
  }
}

export async function DELETE(
  _: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    await prisma.specialOffer.delete({
      where: { id: params.id }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(`Error deleting offer ${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to delete offer' }, 
      { status: 500 }
    );
  }
}
