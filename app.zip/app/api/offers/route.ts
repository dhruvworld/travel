import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import prisma from '@/lib/db/prisma';
import { authOptions } from '@/lib/auth-options';

export async function GET() {
  try {
    const offers = await prisma.specialOffer.findMany({
      orderBy: { 
        createdAt: 'desc' 
      }
    });
    
    return NextResponse.json(offers);
  } catch (error) {
    console.error('Error fetching offers:', error);
    return NextResponse.json(
      { error: 'Failed to fetch offers' }, 
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { 
      title, 
      description, 
      code, 
      discountPercent, 
      startDate, 
      endDate, 
      image,
      active 
    } = await request.json();
    
    if (!title || !description) {
      return NextResponse.json(
        { error: 'Title and description are required' }, 
        { status: 400 }
      );
    }

    const newOffer = await prisma.specialOffer.create({
      data: {
        title,
        description,
        code,
        discountPercent: discountPercent ? parseInt(discountPercent) : null,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        image,
        active: active ?? true
      }
    });
    
    return NextResponse.json(newOffer);
  } catch (error) {
    console.error('Error creating offer:', error);
    return NextResponse.json(
      { error: 'Failed to create offer' }, 
      { status: 500 }
    );
  }
}
