import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import prisma from '@/lib/db/prisma';
import { authOptions } from '@/lib/auth-options';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { url } = await request.json();
    
    if (!url) {
      return NextResponse.json(
        { error: 'Image URL is required' }, 
        { status: 400 }
      );
    }

    // Check if we're using the Package or TourPackage model
    const models = Object.keys(prisma).filter(key => 
      !key.startsWith('_') && typeof prisma[key] === 'object'
    );
    
    let modelToUse = 'packageImage';
    let foreignKey = 'packageId';
    
    if (!models.includes('package') && models.includes('tourPackage')) {
      modelToUse = 'tourPackageImage';
      foreignKey = 'tourPackageId';
    }
    
    // Create image record dynamically based on available model
    const newImage = await prisma[modelToUse].create({
      data: {
        url,
        [foreignKey]: params.id
      }
    });
    
    return NextResponse.json(newImage);
  } catch (error) {
    console.error('Error adding package image:', error);
    return NextResponse.json(
      { error: 'Failed to add package image' }, 
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const searchParams = new URL(request.url).searchParams;
    const imageId = searchParams.get('imageId');
    
    if (!imageId) {
      return NextResponse.json(
        { error: 'Image ID is required' }, 
        { status: 400 }
      );
    }

    // Check which model to use
    const models = Object.keys(prisma).filter(key => 
      !key.startsWith('_') && typeof prisma[key] === 'object'
    );
    
    let modelToUse = 'packageImage';
    
    if (!models.includes('packageImage') && models.includes('tourPackageImage')) {
      modelToUse = 'tourPackageImage';
    }
    
    // Delete image
    await prisma[modelToUse].delete({
      where: { id: imageId }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting package image:', error);
    return NextResponse.json(
      { error: 'Failed to delete package image' }, 
      { status: 500 }
    );
  }
}
