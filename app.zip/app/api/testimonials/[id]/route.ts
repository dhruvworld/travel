import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import prisma from '@/lib/db/prisma';
import { authOptions } from '@/lib/auth-options';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { name, country, feedback, stars, image, active } = await request.json();
    
    if (!name || !feedback) {
      return NextResponse.json(
        { error: 'Name and feedback are required' }, 
        { status: 400 }
      );
    }

    const updatedTestimonial = await prisma.testimonial.update({
      where: { id: params.id },
      data: {
        name,
        country,
        feedback,
        stars: stars || 5,
        image,
        active: active ?? true
      }
    });
    
    return NextResponse.json(updatedTestimonial);
  } catch (error) {
    console.error(`Error updating testimonial ${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to update testimonial' }, 
      { status: 500 }
    );
  }
}

export async function DELETE(
  _: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.isAdmin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    await prisma.testimonial.delete({
      where: { id: params.id }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(`Error deleting testimonial ${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to delete testimonial' }, 
      { status: 500 }
    );
  }
}
