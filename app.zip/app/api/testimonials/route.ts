import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';

export const revalidate = 3600; // Cache for 1 hour

export async function GET() {
  try {
    const testimonials = await prisma.testimonial.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50, // Limit the number of testimonials fetched
    });

    return NextResponse.json(testimonials, { headers: { 'Cache-Control': `s-maxage=${revalidate}` } });
  } catch (error) {
    console.error('Error in GET /api/testimonials:', error);
    return NextResponse.json({ error: 'Failed to fetch testimonials' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { name, feedback, image, stars = 5 } = await request.json();

    if (!name || !feedback) {
      return NextResponse.json({ error: 'Name and feedback are required' }, { status: 400 });
    }

    const newTestimonial = await prisma.testimonial.create({
      data: { name, feedback, image, stars },
    });

    return NextResponse.json(newTestimonial);
  } catch (error) {
    console.error('Error in POST /api/testimonials:', error);
    return NextResponse.json({ error: 'Failed to create testimonial' }, { status: 500 });
  }
}
