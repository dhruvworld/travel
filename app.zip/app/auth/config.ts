// Force dynamic rendering for auth routes
export const dynamic = 'force-dynamic'
export const dynamicParams = true
export const revalidate = 0
