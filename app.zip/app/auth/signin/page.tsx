export const dynamic = 'force-dynamic';

import SignInForm from './SignInForm';

export default function SignInPage() {
  return <SignInForm />;
}
