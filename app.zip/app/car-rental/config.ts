// Force dynamic rendering for car rental route
export const dynamic = 'force-dynamic'
export const dynamicParams = true
export const revalidate = false
