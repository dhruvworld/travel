// Global configuration to force dynamic rendering
export const dynamic = 'force-dynamic'
export const dynamicParams = true
export const revalidate = false // Setting to false instead of 0 for clarity
