// Force dynamic rendering for hotels page
export const dynamic = 'force-dynamic'
export const dynamicParams = true
export const revalidate = false
