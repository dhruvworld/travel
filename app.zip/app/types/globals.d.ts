import { DefaultSession } from 'next-auth';
import { PrismaClient } from '@prisma/client';

declare global {
  // For Prisma Client
  var prisma: PrismaClient | undefined;
}

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      role?: string | null;
      isAdmin?: boolean;
    } & DefaultSession['user']
  }

  interface JWT {
    role?: string | null;
    isAdmin?: boolean;
  }

  interface User {
    id: string;
    role?: string | null;
    isAdmin?: boolean; 
  }
}
